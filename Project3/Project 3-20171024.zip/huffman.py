#Name:
#Section:
#Data Definition

class HuffmanNode:
	def __init__(self, char, freq):
		self.char = char  # actually the character code
		self.freq = freq
		self.code = None
		self.left = None
		self.right = None

   # add any necessary functions you need

#returns true if tree rooted at node a comes before tree rooted at node b 
def comes_before (a, b) :
    pass

def cnt_freq(filename):
    pass
    
    
def create_huff_tree(char_freq):
    pass

def create_code (node):
    pass

def huffman_encode(in_file, out_file):
    pass

def huffman_decode(freqs, encoded_file, decode_file):
    pass

def tree_preord (node):
    pass


