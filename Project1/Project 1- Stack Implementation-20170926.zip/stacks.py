class StackArray:
    """Implements an efficient last-in first-out Abstract Data Type using a Python List"""
        
    def __init__(self, capacity):
        """Creates and empty stack with a capacity"""
        self.capacity = capacity		# this is example for list implementation
        self.items = [None]*capacity 		# this is example for list implementation
        self.num_items = 0 			# this is example for list implementation

    def is_empty(self):
        """Returns true if the stack self is empty and false otherwise"""

    def is_full(self):
        """Returns true if the stack self is full and false otherwise"""

    def push(self, item):

    def pop(self):

    def peek(self):

    def size(self):
       """Returns the number of elements currently in the stack, not the capacity"""
